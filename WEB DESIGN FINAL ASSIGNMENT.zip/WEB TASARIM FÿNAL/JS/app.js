const container=document.querySelector(".container");

document.querySelector(".open-navbar-icon").addEventListener('click',()=>{
    container.classList.add("change");
});

document.querySelector(".close-navbar-icon").addEventListener('click',()=>{
    container.classList.remove("change")
});

const colors= ["orange","black","orange","black","orange"];

let i=0;

Array.from(document.querySelectorAll(".nav-link")).forEach(item =>{
    item.style.cssText=`background-color:${colors[i++]}`;
});

const todoInput=document.querySelector(".todo-input");
const todoButton=document.querySelector(".todo-button");
const todoList=document.querySelector(".todo-list");

document.addEventListener("DOMContentLoaded",gettodos);

todoButton.addEventListener,('click',addTodo);

todoList.addEventListener('click',deletetodo);

function addTodo(event){

    const todoDiv=document.createElement("div");
    todoDiv.classList.add("todo");

    const newTodo=document.createElement("li");
    newTodo.innerText=todoInput.value;
    newTodo.classList.add("todo-item");

    todoDiv.appendChild(newTodo);

    saveLocalTodos(todoInput.value);

    todoList.appendChild(todoDiv);

    const trashButton=document.createElement("button");
    trashButton.innerHTML='<i class="fas fa-trash"></i>';
    trashButton.classList.add("trash-btn");
    todoDiv.appendChild(trashButton);

    todoInput.value="";

    event.preventDefault();


}

function deleteTodo(event){
    const item=event.target;

    if(item.classList[0]==="trash-btn"){
        const todo=item.parentElement;
        todo.remove();
    }
}

function saveLocalTodos(todo){

    let todos;
    if(localStorage.getItem("todos")===null){
        todos=[];
    }
    else{
        todos=JSON.parse(localStorage.getItem("todos"));
    }
    todos.push(todo);
    localStorage.setItem("todos",JSON.stringify(todos));
}

function gettodos(){
    let todos;

    if(localStorage.getItem("todos")===null){
        todos=[];
    }
    else{
        todos=JSON.parse(localStorage.getItem("todos"));
    }
    todos.forEach(function(todo){
        const todoDiv=document.createElement("div");
    todoDiv.classList.add("todo");

    const newTodo=document.createElement("li");
    newTodo.innerText=todo;
    newTodo.classList.add("todo-item");

    todoDiv.appendChild(newTodo);

    todoList.appendChild(todoDiv);

    const trashButton=document.createElement("button");
    trashButton.innerHTML='<i class="fas fa-trash"></i>';
    trashButton.classList.add("trash-btn");
    todoDiv.appendChild(trashButton);

    todoInput.value="";
      
    });
    
}
